<footer>
      <div class="first_div_footer">
      </div>
      <span class="powered_by">&copy Powered by G04 2020</span>
    </footer>
    <script src="button.js"></script>
  </body>
</html>